</main><!-- /.container -->
<script src="https://getbootstrap.com/docs/4.4/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-6khuMg9gaYr5AxOqhkVIODVIvm9ynTT5J4V1cfthmT+emCG6yVmEZsRHdxlotUnm"
        crossorigin="anonymous"></script>

<?php
if (function_exists('footer_content')) footer_content($appleMusicKit);
?>
</body>
</html>
